using System;

namespace Assignment02 
{
    public enum Status 
    { New,Active,Dropout,Graduated };
}

